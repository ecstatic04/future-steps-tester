# Future Steps Tester

This is a small Android research/test app that attempts to insert a `StepsRecord` into Android Health Connect using a user-selected date, time and step count.

## What it tests

The app deliberately allows dates in the future. Health Connect's public API exposes start/end timestamps for `StepsRecord`, but Google's documentation does not state that future-dated step records are accepted. The app therefore treats future insertion as an experiment rather than a guaranteed supported feature.

## Setup

1. Open this project in Android Studio.
2. Let Gradle sync.
3. Build and install on an Android phone with Google Play services.
4. Open the app.
5. Grant READ_STEPS and WRITE_STEPS permissions.
6. Select a future date, start time, end time and step count.
7. Tap Write Steps Record.
8. Check Health Connect → Data and access → Activity → Steps → See all entries.

## Important

A successful `insertRecords()` call is not by itself proof that Google Fit will display the future record. Health Connect is the datastore being tested. If Google Fit is connected as a data source, separately verify whether and when it surfaces the record.

The app marks records as manually entered through Health Connect metadata.

## Current limitation

This project is source code, not a precompiled APK. Build it with Android Studio so the APK is signed for your device.
