package com.neeraj.futuresteps

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.PermissionController
import androidx.health.connect.client.records.StepsRecord
import androidx.health.connect.client.records.metadata.Metadata
import androidx.health.connect.client.request.ReadRecordsRequest
import androidx.health.connect.client.time.TimeRangeFilter
import kotlinx.coroutines.*
import java.time.*
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var healthConnectClient: HealthConnectClient
    private lateinit var dateButton: Button
    private lateinit var startButton: Button
    private lateinit var endButton: Button
    private lateinit var stepsInput: EditText
    private lateinit var status: TextView

    private var selectedDate = LocalDate.now()
    private var startTime = LocalTime.of(9, 0)
    private var endTime = LocalTime.of(10, 0)

    private val permissions = setOf(
        "android.permission.health.WRITE_STEPS",
        "android.permission.health.READ_STEPS"
    )

    private val permissionLauncher =
        registerForActivityResult(PermissionController.createRequestPermissionResultContract()) {
            updateStatus("Permissions updated. Try writing the record.")
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        healthConnectClient = HealthConnectClient.getOrCreate(this)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 40, 40, 40)
        }

        val title = TextView(this).apply {
            text = "Future Steps Tester"
            textSize = 24f
        }

        val info = TextView(this).apply {
            text = "Experimental: attempts to write a StepsRecord using the date/time you choose."
            textSize = 15f
            setPadding(0, 20, 0, 30)
        }

        dateButton = Button(this).apply { text = "Date: $selectedDate" }
        startButton = Button(this).apply { text = "Start: $startTime" }
        endButton = Button(this).apply { text = "End: $endTime" }

        stepsInput = EditText(this).apply {
            hint = "Step count, e.g. 5000"
            inputType = 2
        }

        val permissionsButton = Button(this).apply {
            text = "Grant Health Connect permissions"
            setOnClickListener {
                permissionLauncher.launch(permissions)
            }
        }

        val writeButton = Button(this).apply {
            text = "Write Steps Record"
            setOnClickListener { writeRecord() }
        }

        status = TextView(this).apply {
            text = "Ready."
            textSize = 16f
            setPadding(0, 25, 0, 0)
        }

        dateButton.setOnClickListener { pickDate() }
        startButton.setOnClickListener { pickTime(true) }
        endButton.setOnClickListener { pickTime(false) }

        layout.addView(title)
        layout.addView(info)
        layout.addView(dateButton)
        layout.addView(startButton)
        layout.addView(endButton)
        layout.addView(stepsInput)
        layout.addView(permissionsButton)
        layout.addView(writeButton)
        layout.addView(status)

        setContentView(layout)
    }

    private fun pickDate() {
        DatePickerDialog(
            this,
            { _, y, m, d ->
                selectedDate = LocalDate.of(y, m + 1, d)
                dateButton.text = "Date: $selectedDate"
            },
            selectedDate.year,
            selectedDate.monthValue - 1,
            selectedDate.dayOfMonth
        ).show()
    }

    private fun pickTime(isStart: Boolean) {
        val t = if (isStart) startTime else endTime
        TimePickerDialog(
            this,
            { _, h, m ->
                val chosen = LocalTime.of(h, m)
                if (isStart) {
                    startTime = chosen
                    startButton.text = "Start: $startTime"
                } else {
                    endTime = chosen
                    endButton.text = "End: $endTime"
                }
            },
            t.hour,
            t.minute,
            true
        ).show()
    }

    private fun writeRecord() {
        val count = stepsInput.text.toString().toLongOrNull()
        if (count == null || count < 1 || count > 1_000_000) {
            updateStatus("Enter a step count from 1 to 1,000,000.")
            return
        }

        if (!endTime.isAfter(startTime)) {
            updateStatus("End time must be after start time.")
            return
        }

        val zone = ZoneId.systemDefault()
        val start = ZonedDateTime.of(selectedDate, startTime, zone)
        val end = ZonedDateTime.of(selectedDate, endTime, zone)

        val record = StepsRecord(
            startTime = start.toInstant(),
            startZoneOffset = start.offset,
            endTime = end.toInstant(),
            endZoneOffset = end.offset,
            count = count,
            metadata = Metadata.manualEntry()
        )

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val result = healthConnectClient.insertRecords(listOf(record))
                withContext(Dispatchers.Main) {
                    updateStatus(
                        "WRITE SUCCEEDED\n" +
                        "Record ID: ${result.recordUids.firstOrNull() ?: "unknown"}\n" +
                        "Date/time: $selectedDate $startTime–$endTime\n" +
                        "Steps: $count\n\n" +
                        "Now check Health Connect → Data and access → Activity → Steps."
                    )
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    updateStatus(
                        "WRITE FAILED\n${e.javaClass.simpleName}: ${e.message}"
                    )
                }
            }
        }
    }

    private fun updateStatus(text: String) {
        status.text = text
    }
}
